

storeNum1 = int(input("Enter the Num1 :-"))
storeNum2 = int(input("Enter the Num1 :-"))

print("The value of Num1 is :-",storeNum1)
print("The value of Num2 is :-",storeNum2)

addNum = storeNum1 + storeNum2
print("The Addition is num1 & num2 is :-",addNum)

sqNum = storeNum1 * storeNum1
print("The Square of Num1 is :-",sqNum)

PowNum = storeNum1** storeNum2
print("The power is :-",PowNum)