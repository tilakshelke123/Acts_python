
def divide11 (num):
   
    return num %11==0
num = int(input("Enter the Argument :-"))
result =divide11(num)
print("result",result)