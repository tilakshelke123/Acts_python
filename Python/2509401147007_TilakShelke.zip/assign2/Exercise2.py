def areaOfCircle (radius):
   
    return 3.14* (radius *radius)
radius = int(input("Enter the radius :-"))
result =areaOfCircle(radius)
print("The Area of circle is ",result)